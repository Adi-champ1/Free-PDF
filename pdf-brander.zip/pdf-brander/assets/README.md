Optional default files — commit them once and the app pre-loads them
(anything uploaded in the app overrides them):

- logo.png       -> logo watermark (transparent PNG recommended)
- playstore.png  -> Play Store badge (otherwise a built-in button is used)
- header.pdf     -> page(s) added at the start
- footer.pdf     -> page(s) added at the end
